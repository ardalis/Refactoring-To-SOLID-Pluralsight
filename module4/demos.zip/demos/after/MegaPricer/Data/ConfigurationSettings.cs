﻿namespace MegaPricer.Data;

public static class ConfigurationSettings
{
  public static string ConnectionString = "Data Source=database.sqlite";

  public static string DefaultPassword = "Pass@word1";
  public static string AdminRoleId = "aab4fac1-c546-41de-aebc-a14da6895711";
  public static string AdminUserId = "b74ddd14-6340-4840-95c2-abcdef4843e5";
}
